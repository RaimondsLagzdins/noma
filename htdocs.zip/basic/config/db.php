<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=http://www.raimondsl.id.lv;dbname=timeklaTehnologijas',
    'username' => 'admin',
    'password' => 'parole123',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
